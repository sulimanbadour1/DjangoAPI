Details
uperuser’s username: LittleLemon
password : 123456789



user1 username : Mic 
user1 password : 12341234@


user2 username :Manager
user2 password : 12341234@